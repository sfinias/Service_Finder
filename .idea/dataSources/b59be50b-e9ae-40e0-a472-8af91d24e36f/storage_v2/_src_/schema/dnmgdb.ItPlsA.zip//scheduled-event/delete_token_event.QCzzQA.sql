create definer = admin@`%` event delete_token_event on schedule
  at '2018-11-27 16:16:53'
  on completion preserve
  enable
  do
  BEGIN
      DELETE FROM verificationToken WHERE generatedTokenDateTime < DATE_SUB(NOW(), INTERVAL 7 DAY);
END;

